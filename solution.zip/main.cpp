#include <iostream>
#include <vector>
#include <cstdint>
#include <string>
#include <sstream>
#include <cassert>
#include <limits>

using namespace std;

struct Slot {
    uint32_t tag;
    bool valid;
    uint64_t lastUsed;
    Slot() : tag(0), valid(false), lastUsed(0) {}
};

struct Set {
    vector<Slot> slots;
    Set(int blocksPerSet) : slots(blocksPerSet) {}
};

struct Cache {
    vector<Set> sets;
    uint64_t timestamp;
    int blocksPerSet;
    int blockSize;

    Cache(int numSets, int blocksPerSet, int blockSize)
        : sets(numSets, Set(blocksPerSet)), timestamp(0), blocksPerSet(blocksPerSet), blockSize(blockSize) {
        assert((numSets & (numSets - 1)) == 0 && "Number of sets must be a power of 2");
        assert((blockSize & (blockSize - 1)) == 0 && "Block size must be a power of 2");
        assert(blockSize >= 4 && "Block size must be at least 4");
    }

    void access(uint32_t address, char operation) {
        uint32_t setIndex = (address / blockSize) % sets.size();
        uint32_t tag = address / (blockSize * sets.size());

        auto& set = sets[setIndex];
        bool hit = false;

        for (auto& slot : set.slots) {
            if (slot.valid && slot.tag == tag) {
                slot.lastUsed = timestamp++;
                hit = true;
                break;
            }
        }

        if (!hit) {
            replaceBlock(setIndex, tag);
        }

        // Update the statistics here (omitted for brevity)
    }

    void replaceBlock(uint32_t setIndex, uint32_t tag) {
        auto& set = sets[setIndex];
        auto lruIt = min_element(set.slots.begin(), set.slots.end(),
                                 [](const Slot& a, const Slot& b) { return a.lastUsed < b.lastUsed; });

        lruIt->valid = true;
        lruIt->tag = tag;
        lruIt->lastUsed = timestamp++;
    }
};

void parse_line(const std::string& line, char& operation, uint32_t& address) {
    stringstream ss(line);
    ss >> operation >> std::hex >> address;
    // Ignoring the size field as specified
}

void simulate_cache(const std::string& filename, Cache& cache) {
    ifstream trace_file(filename);
    if (!trace_file) {
        cerr << "Could not open trace file." << endl;
        exit(1);
    }

    string line;
    while (getline(trace_file, line)) {
        char operation;
        uint32_t address;
        parse_line(line, operation, address);
        cache.access(address, operation);
    }
}

int main(int argc, char* argv[]) {
    if (argc != 5) {
        cerr << "Usage: " << argv[0] << " <numSets> <blocksPerSet> <blockSize> <tracefile>" << endl;
        return 1;
    }

    int numSets = stoi(argv[1]);
    int blocksPerSet = stoi(argv[2]);
    int blockSize = stoi(argv[3]);
    string tracefile = argv[4];

    Cache cache(numSets, blocksPerSet, blockSize);
    simulate_cache(tracefile, cache);

    return 0;
}
