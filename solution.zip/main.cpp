#include <stdio.h>

int main() {
    // Your code here
    printf("Hello world!");
    return 0;
}