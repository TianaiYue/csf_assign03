list team members, document who did what, discuss
anything interesting about your implementation.

Team members: Cassie Zhang xzhan304, Tianai Yue tyue4

Both Cassie and Tianai did relatively equal amounts of work and effort.

